# Description

**Type:** Distributed

This resource is responsible for managing the search crawl impact rules in the
search service application. You can create new rules, change existing rules and
remove existing rules.

The default value for the Ensure parameter is Present. When you omit this
parameter the crawl rule is created.
