# Description

**Type:** Distributed

This resource is responsible for configuring the Security Token Service within
the local SharePoint farm. Using Ensure equals to Absent is not supported.
This resource can only apply configuration, not ensure they don't exist.
