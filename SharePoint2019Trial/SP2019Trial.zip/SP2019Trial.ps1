Configuration SharePointServer2019
{
    Import-DscResource -ModuleName SharePointDSC -ModuleVersion 3.0.0.0
    Import-DscResource -ModuleName xDownloadISO -ModuleVersion 1.0

    Node localhost
    {
        xDownloadISO DownloadBinaries
        {
            SourcePath               = "https://download.microsoft.com/download/8/1/4/8144DA0D-FB9A-48B8-B56E-2C12E0C30079/en-us/16.0.10711.37301_OfficeServer_none_ship_x64_en-us_dvd/officeserver_en-us.img"
            DestinationDirectoryPath = "C:\SP2019"
        }

        SPInstallPrereqs Prereqs
        {
            OnlineMode           = $true
            InstallerPath        = "C:\SP2019\prerequisiteinstaller.exe"
        }

        SPInstall Install
        {
            BinaryDir            = "C:\SP2019"
            ProductKey           = "M692G-8N2JP-GG8B2-2W2P7-YY7J6"
            Ensure               = "Present"
        }

        LocalConfigurationManager 
        {
            ConfigurationMode = 'ApplyAndMonitor'
            RebootNodeIfNeeded = $true 
        }
    }
}